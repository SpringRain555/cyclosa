import { setTimeout as scheduleTimeout } from 'node:timers';

export const DEFAULT_SHUTDOWN_BUDGET = Object.freeze({
  flushMs: 100,
  graceMs: 3000,
  closeMs: 2000,
});

const POLL_MS = 50;

export const systemShutdownClock = Object.freeze({
  sleep: (ms) => new Promise((resolve) => scheduleTimeout(resolve, ms).unref()),
  now: () => Date.now(),
});

/** Run the common bounded shutdown sequence; app-specific cleanup stays in its target callbacks. */
export async function shutdownSequence(
  target,
  budget = DEFAULT_SHUTDOWN_BUDGET,
  clock = systemShutdownClock,
) {
  const supportsCancellation = typeof target.cancelAll === 'function';
  const cancelled = supportsCancellation ? target.cancelAll() : undefined;
  if (budget.flushMs > 0) await clock.sleep(budget.flushMs);

  const activeCount = target.activeCount ?? target.activeLongOperations ?? (() => 0);
  let settled = activeCount() === 0;
  if (!settled) {
    const deadline = clock.now() + budget.graceMs;
    while (clock.now() < deadline) {
      await clock.sleep(POLL_MS);
      if (activeCount() === 0) {
        settled = true;
        break;
      }
    }
  }

  target.destroyConnections();
  let closed = false;
  await Promise.race([
    target.close().then(
      () => {
        closed = true;
      },
      () => {
        closed = false;
      },
    ),
    clock.sleep(budget.closeMs),
  ]);

  let finalized = true;
  try {
    target.finalize?.();
  } catch {
    finalized = false;
  }
  return {
    ...(supportsCancellation ? { cancelled } : {}),
    settled,
    closed,
    finalized,
  };
}
