/** Read a local application's health endpoint without treating arbitrary HTTP as ownership. */
export async function readHealthz({ url, timeoutMs = 2000, fetchImpl = globalThis.fetch }) {
  try {
    const response = await fetchImpl(url, { signal: globalThis.AbortSignal.timeout(timeoutMs) });
    let body = null;
    try {
      body = await response.json();
    } catch {
      // A non-JSON listener is still an occupied endpoint, but not a recognized app.
    }
    return { reachable: true, status: response.status, body };
  } catch (error) {
    const code =
      error && typeof error === 'object' && 'cause' in error ? error.cause?.code : undefined;
    return { reachable: false, errorCode: code };
  }
}

/** Classify the endpoint by an app-owned identity field and recognize startup readiness. */
export async function probeHealthz({
  url,
  identityKey,
  identityValue,
  timeoutMs = 2000,
  fetchImpl = globalThis.fetch,
}) {
  const result = await readHealthz({ url, timeoutMs, fetchImpl });
  if (!result.reachable) {
    return result.errorCode === 'ECONNREFUSED' ? { owner: 'free' } : { owner: 'other' };
  }
  if (result.status === 503) return { owner: 'starting', body: result.body };
  if (result.status !== 200 || result.body?.[identityKey] !== identityValue) {
    return { owner: 'other', body: result.body };
  }
  return { owner: 'ours', body: result.body };
}
