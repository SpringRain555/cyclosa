import { randomUUID } from 'node:crypto';
import { mkdir, open, readFile, rename, rm, stat, writeFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { dirname, isAbsolute, join, parse, relative, resolve, sep } from 'node:path';
import process from 'node:process';

/*
 * Where an app's data root is: the shared mechanism behind "four steps when there is no pointer".
 *
 *   0. a dev/test override              -> use it; never read or write the pointer
 *   1. the pointer file exists           -> obey it; a broken pointer is an error, never a fallback
 *   2. <program folder>/userdata has a marker -> use it (no pointer: the folder may move)
 *   3. <state dir>/data has a marker     -> use it (no pointer)
 *   4. none of the above                 -> the app asks: program folder / user folder / other...
 *
 * Only mechanism lives here. How to ask (a dialog, a web page), the layout under the data root and
 * which file is the marker are each app's policy and are passed in by the caller.
 */

export const POINTER_FILE_NAME = 'system_paths.json';
export const POINTER_VERSION = 1;
/** The "keep it in the program folder" choice: `<program folder>/userdata`. Must be git-ignored. */
export const PROGRAM_DATA_FOLDER = 'userdata';
/** The "this computer's user folder" choice: `<state dir>/data`, next to the pointer file. */
export const USER_DATA_FOLDER = 'data';

function nonEmpty(value) {
  return typeof value === 'string' && value.trim() !== '';
}

function isInside(child, parent) {
  const rel = relative(parent, child);
  return rel === '' || !(rel === '..' || rel.startsWith(`..${sep}`) || isAbsolute(rel));
}

async function isFile(path) {
  try {
    return (await stat(path)).isFile();
  } catch {
    return false;
  }
}

/**
 * `%LOCALAPPDATA%/<appDir>`, where the pointer and the user-folder data root live. Derived at call
 * time, so a test process that replaces LOCALAPPDATA (or sets the override) never sees the real one.
 */
export function stateDir({ appDir, env = process.env, stateDirOverride }) {
  if (nonEmpty(stateDirOverride)) return resolve(stateDirOverride);
  const base = nonEmpty(env.LOCALAPPDATA)
    ? env.LOCALAPPDATA
    : nonEmpty(env.XDG_DATA_HOME)
      ? env.XDG_DATA_HOME
      : join(homedir(), '.local', 'share');
  return join(base, appDir);
}

export function pointerFilePath(where) {
  return join(stateDir(where), POINTER_FILE_NAME);
}

export function userDataRoot(where) {
  return join(stateDir(where), USER_DATA_FOLDER);
}

/** `<programRoot>/userdata`, or null when the app has no usable program folder. */
export function programDataRoot(programRoot) {
  return nonEmpty(programRoot) ? join(resolve(programRoot), PROGRAM_DATA_FOLDER) : null;
}

/** A marker is a file, never a folder: a launcher may create `logs/` before anyone chose. */
export async function hasMarker(root, markers) {
  for (const marker of markers) {
    if (await isFile(join(root, marker))) return true;
  }
  return false;
}

/** Read the pointer. Accepts `data_root` and the older Node spelling `dataRoot`. */
export async function readPointer(pointerPath) {
  let text;
  try {
    text = await readFile(pointerPath, 'utf8');
  } catch (error) {
    if (error?.code === 'ENOENT') return { kind: 'missing', pointerPath };
    return { kind: 'malformed', pointerPath, reason: String(error?.code ?? error) };
  }
  let parsed;
  try {
    parsed = JSON.parse(text.replace(/^\uFEFF/, ''));
  } catch (error) {
    return { kind: 'malformed', pointerPath, reason: String(error?.message ?? error) };
  }
  const isObject = parsed !== null && typeof parsed === 'object' && !Array.isArray(parsed);
  const value = isObject ? (nonEmpty(parsed.data_root) ? parsed.data_root : parsed.dataRoot) : null;
  if (!nonEmpty(value) || value.includes('\0') || !isAbsolute(value)) {
    return {
      kind: 'malformed',
      pointerPath,
      reason: 'data_root is missing or not an absolute path',
    };
  }
  return { kind: 'ok', pointerPath, dataRoot: resolve(value), fields: parsed };
}

/** Exists, is a folder and accepts a new file. Creates and removes one probe file, nothing else. */
export async function checkDataRoot(dataRoot) {
  try {
    if (!(await stat(dataRoot)).isDirectory()) return 'data-root-missing';
  } catch (error) {
    return error?.code === 'ENOENT' ? 'data-root-missing' : 'data-root-not-writable';
  }
  const probe = join(dataRoot, `.write-check-${randomUUID()}`);
  try {
    const handle = await open(probe, 'wx');
    await handle.close();
    await rm(probe, { force: true });
    return 'ok';
  } catch {
    await rm(probe, { force: true }).catch(() => undefined);
    return 'data-root-not-writable';
  }
}

/** The four steps. Looks only: never creates the data root, its layout or the pointer. */
export async function detectDataLocation({
  appDir,
  markers,
  programRoot = null,
  override,
  env = process.env,
  stateDirOverride,
}) {
  const where = { appDir, env, stateDirOverride };
  const pointerPath = pointerFilePath(where);
  if (nonEmpty(override)) {
    return { kind: 'found', source: 'override', dataRoot: resolve(override), pointerPath };
  }

  const pointer = await readPointer(pointerPath);
  if (pointer.kind === 'malformed') {
    return { kind: 'error', code: 'pointer-malformed', pointerPath, reason: pointer.reason };
  }
  if (pointer.kind === 'ok') {
    const state = await checkDataRoot(pointer.dataRoot);
    if (state !== 'ok') {
      return {
        kind: 'error',
        code: state,
        source: 'pointer',
        pointerPath,
        dataRoot: pointer.dataRoot,
      };
    }
    return { kind: 'found', source: 'pointer', dataRoot: pointer.dataRoot, pointerPath };
  }

  const candidates = [
    ['program-folder', programDataRoot(programRoot)],
    ['user-folder', userDataRoot(where)],
  ];
  for (const [source, dataRoot] of candidates) {
    if (dataRoot === null || !(await hasMarker(dataRoot, markers))) continue;
    const state = await checkDataRoot(dataRoot);
    if (state !== 'ok') return { kind: 'error', code: state, source, pointerPath, dataRoot };
    return { kind: 'found', source, dataRoot, pointerPath };
  }

  return {
    kind: 'choose',
    pointerPath,
    programDataRoot: programDataRoot(programRoot),
    userDataRoot: userDataRoot(where),
  };
}

/** The nearest folder above `dataRoot` (not `dataRoot` itself) that holds a marker, or null. */
async function enclosingDataRoot(dataRoot, markers) {
  for (let dir = dirname(dataRoot); ; dir = dirname(dir)) {
    if (await hasMarker(dir, markers)) return dir;
    if (dirname(dir) === dir) return null;
  }
}

/**
 * Can "other location..." use this folder? Refuses a whole drive, anything inside the program folder
 * (pick the program-folder choice instead: only `userdata` is git-ignored, and a pointer there would
 * break when the folder moves) and any folder inside an existing data root, i.e. below a folder that
 * holds a marker. Using one would start an empty data root inside the real one and point the pointer
 * past it. That covers the inner folder of a nested marker (`library/` for `library/app.sqlite`) as
 * well as every other subfolder, and apps whose marker sits at the top. Looks only.
 */
export async function inspectOtherFolder({ folder, markers, programRoot = null }) {
  if (!nonEmpty(folder) || folder.includes('\0') || !isAbsolute(folder)) {
    return { ok: false, code: 'not-absolute' };
  }
  const dataRoot = resolve(folder);
  if (parse(dataRoot).root === dataRoot) return { ok: false, code: 'drive-root', dataRoot };
  if (nonEmpty(programRoot) && isInside(dataRoot, resolve(programRoot))) {
    return { ok: false, code: 'inside-program-folder', dataRoot };
  }
  const existingRoot = await enclosingDataRoot(dataRoot, markers);
  if (existingRoot !== null) {
    return { ok: false, code: 'inside-data-root', dataRoot, existingRoot };
  }
  return { ok: true, dataRoot, hasData: await hasMarker(dataRoot, markers) };
}

/** Write the pointer atomically: a staging file, then a rename over the old one. */
export async function writePointer({
  appDir,
  env = process.env,
  stateDirOverride,
  dataRoot,
  fields,
}) {
  if (!nonEmpty(dataRoot) || !isAbsolute(dataRoot)) {
    throw new TypeError('dataRoot must be an absolute path');
  }
  const pointerPath = pointerFilePath({ appDir, env, stateDirOverride });
  await mkdir(dirname(pointerPath), { recursive: true });
  const staging = `${pointerPath}.${randomUUID()}.tmp`;
  const payload = { ...fields, version: POINTER_VERSION, data_root: resolve(dataRoot) };
  try {
    await writeFile(staging, `${JSON.stringify(payload, null, 2)}\n`, {
      encoding: 'utf8',
      flag: 'wx',
    });
    await rename(staging, pointerPath);
  } catch (error) {
    await rm(staging, { force: true }).catch(() => undefined);
    throw error;
  }
  return pointerPath;
}

/**
 * Turn a choice into a usable data root, in the order the contract requires: create the folder,
 * prove it is writable, let the app build its layout and marker (`initialize`), and only then
 * write the pointer (for "other" only). If `initialize` throws, no pointer is written.
 */
export async function prepareLocation({
  choice,
  appDir,
  markers,
  programRoot = null,
  folder,
  env = process.env,
  stateDirOverride,
  initialize,
}) {
  const where = { appDir, env, stateDirOverride };
  let dataRoot;
  if (choice === 'program-folder') {
    dataRoot = programDataRoot(programRoot);
    if (dataRoot === null) return { ok: false, code: 'program-folder-unavailable' };
  } else if (choice === 'user-folder') {
    dataRoot = userDataRoot(where);
  } else if (choice === 'other') {
    const inspected = await inspectOtherFolder({ folder, markers, programRoot });
    if (!inspected.ok) return inspected;
    dataRoot = inspected.dataRoot;
  } else {
    return { ok: false, code: 'unknown-choice' };
  }

  try {
    await mkdir(dataRoot, { recursive: true });
  } catch (error) {
    return {
      ok: false,
      code: 'data-root-not-writable',
      dataRoot,
      reason: String(error?.code ?? error),
    };
  }
  if ((await checkDataRoot(dataRoot)) !== 'ok') {
    return { ok: false, code: 'data-root-not-writable', dataRoot };
  }

  const hasData = await hasMarker(dataRoot, markers);
  if (initialize) await initialize(dataRoot, { hasData });
  const pointerPath = choice === 'other' ? await writePointer({ ...where, dataRoot }) : null;
  return {
    ok: true,
    source: choice === 'other' ? 'pointer' : choice,
    dataRoot,
    hasData,
    pointerPath,
  };
}
