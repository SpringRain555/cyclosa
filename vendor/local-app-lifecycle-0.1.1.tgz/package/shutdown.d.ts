export interface ShutdownBudget {
  readonly flushMs: number;
  readonly graceMs: number;
  readonly closeMs: number;
}

export interface ShutdownClock {
  readonly sleep: (ms: number) => Promise<void>;
  readonly now: () => number;
}

export interface ShutdownTarget {
  readonly cancelAll?: () => number;
  readonly activeCount?: () => number;
  readonly activeLongOperations?: () => number;
  readonly destroyConnections: () => void;
  readonly close: () => Promise<void>;
  readonly finalize?: () => void;
}

export interface ShutdownOutcome {
  readonly cancelled?: number;
  readonly settled: boolean;
  readonly closed: boolean;
  readonly finalized: boolean;
}

export const DEFAULT_SHUTDOWN_BUDGET: ShutdownBudget;
export const systemShutdownClock: ShutdownClock;
export function shutdownSequence(
  target: ShutdownTarget,
  budget?: ShutdownBudget,
  clock?: ShutdownClock,
): Promise<ShutdownOutcome>;
