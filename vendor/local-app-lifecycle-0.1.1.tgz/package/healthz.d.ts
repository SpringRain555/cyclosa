export interface HealthzResult {
  readonly reachable: boolean;
  readonly status?: number;
  readonly body?: unknown;
  readonly errorCode?: string;
}

export type HealthzOwner = 'ours' | 'other' | 'free' | 'starting';

export interface HealthzProbe {
  readonly owner: HealthzOwner;
  readonly body?: unknown;
}

export function readHealthz(input: {
  readonly url: string;
  readonly timeoutMs?: number;
  readonly fetchImpl?: typeof fetch;
}): Promise<HealthzResult>;

export function probeHealthz(input: {
  readonly url: string;
  readonly identityKey: string;
  readonly identityValue: string;
  readonly timeoutMs?: number;
  readonly fetchImpl?: typeof fetch;
}): Promise<HealthzProbe>;
