export const POINTER_FILE_NAME: 'system_paths.json';
export const POINTER_VERSION: 1;
export const PROGRAM_DATA_FOLDER: 'userdata';
export const USER_DATA_FOLDER: 'data';

/** Where the pointer lives: `%LOCALAPPDATA%/<appDir>`, or the app's state-dir override. */
export interface StateDirOptions {
  readonly appDir: string;
  readonly env?: NodeJS.ProcessEnv;
  readonly stateDirOverride?: string;
}

export type DataLocationSource = 'override' | 'pointer' | 'program-folder' | 'user-folder';
export type DataLocationChoice = 'program-folder' | 'user-folder' | 'other';
export type DataLocationErrorCode =
  'pointer-malformed' | 'data-root-missing' | 'data-root-not-writable';
/** `inside-data-root`: some folder above it already holds a marker (0.3.0; was `inner-data-folder`). */
export type OtherFolderRejection =
  'not-absolute' | 'drive-root' | 'inside-program-folder' | 'inside-data-root';

export type PointerReadResult =
  | {
      readonly kind: 'ok';
      readonly pointerPath: string;
      readonly dataRoot: string;
      readonly fields: Readonly<Record<string, unknown>>;
    }
  | { readonly kind: 'missing'; readonly pointerPath: string }
  | { readonly kind: 'malformed'; readonly pointerPath: string; readonly reason: string };

export type DetectedLocation =
  | {
      readonly kind: 'found';
      readonly source: DataLocationSource;
      readonly dataRoot: string;
      readonly pointerPath: string;
    }
  | {
      readonly kind: 'choose';
      readonly pointerPath: string;
      readonly programDataRoot: string | null;
      readonly userDataRoot: string;
    }
  | {
      readonly kind: 'error';
      readonly code: DataLocationErrorCode;
      readonly pointerPath: string;
      readonly source?: DataLocationSource;
      readonly dataRoot?: string;
      readonly reason?: string;
    };

export type OtherFolderInspection =
  | { readonly ok: true; readonly dataRoot: string; readonly hasData: boolean }
  | {
      readonly ok: false;
      readonly code: OtherFolderRejection;
      readonly dataRoot?: string;
      /** `inside-data-root` only: the nearest folder above that holds a marker. */
      readonly existingRoot?: string;
    };

export type PreparedLocation =
  | {
      readonly ok: true;
      readonly source: Exclude<DataLocationSource, 'override'>;
      readonly dataRoot: string;
      readonly hasData: boolean;
      /** Only the "other" choice writes a pointer. */
      readonly pointerPath: string | null;
    }
  | {
      readonly ok: false;
      readonly code:
        | OtherFolderRejection
        | 'program-folder-unavailable'
        | 'data-root-not-writable'
        | 'unknown-choice';
      readonly dataRoot?: string;
      /** `inside-data-root` only: the nearest folder above that holds a marker. */
      readonly existingRoot?: string;
      readonly reason?: string;
    };

export function stateDir(options: StateDirOptions): string;
export function pointerFilePath(options: StateDirOptions): string;
export function userDataRoot(options: StateDirOptions): string;
export function programDataRoot(programRoot: string | null | undefined): string | null;
export function hasMarker(root: string, markers: readonly string[]): Promise<boolean>;
export function readPointer(pointerPath: string): Promise<PointerReadResult>;
export function checkDataRoot(
  dataRoot: string,
): Promise<'ok' | 'data-root-missing' | 'data-root-not-writable'>;

export function detectDataLocation(
  options: StateDirOptions & {
    /** Files relative to a data root; the first is the current marker, the rest legacy layouts. */
    readonly markers: readonly string[];
    readonly programRoot?: string | null;
    readonly override?: string;
  },
): Promise<DetectedLocation>;

export function inspectOtherFolder(options: {
  readonly folder: string;
  readonly markers: readonly string[];
  readonly programRoot?: string | null;
}): Promise<OtherFolderInspection>;

export function writePointer(
  options: StateDirOptions & {
    readonly dataRoot: string;
    readonly fields?: Readonly<Record<string, unknown>>;
  },
): Promise<string>;

export function prepareLocation(
  options: StateDirOptions & {
    readonly choice: DataLocationChoice;
    readonly markers: readonly string[];
    readonly programRoot?: string | null;
    readonly folder?: string;
    /** Build the app's layout and marker. Runs before the pointer is written; throwing stops it. */
    readonly initialize?: (
      dataRoot: string,
      info: { readonly hasData: boolean },
    ) => Promise<void> | void;
  },
): Promise<PreparedLocation>;
